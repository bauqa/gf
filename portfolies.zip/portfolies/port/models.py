from django.db import models

# Create your models here.


class Algys(models.Model):
    name  = models.CharField(max_length=1000, verbose_name="Алғыс хат")
    img = models.ImageField(upload_to="algys/",verbose_name="Фото")
    def __str__(self):
        return self.name
    class Meta:
        verbose_name = "Алғыс хат"
        
        verbose_name_plural = "Алғыс хаттар"
        ordering = ['id']
class Jymys(models.Model):
    
    img = models.ImageField(upload_to="jymys/",verbose_name="Жұмыс фотосы")

    class Meta:
        verbose_name = "Жұмыс фотосы"
        
        verbose_name_plural = "Жұмыс фотолары"
        ordering = ['id']
class Natizhe(models.Model):
    img = models.ImageField(upload_to="natizhe/",verbose_name="фото")

    class Meta:
        verbose_name = "Нәтиже"
        verbose_name_plural = "Нәтижелер"
        
        ordering = ['id']