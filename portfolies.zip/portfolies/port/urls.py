from django.urls import path
from . import views

urlpatterns = [
    path('', views.index,name="home"),
    path('algys/',views.AlgysT.as_view(),name="algys"),
    path('jymys/',views.JymysT.as_view(),name="jymys"),
    path('statistika/',views.statistika,name="statistika"),
    path('natizhe/',views.NatizheT.as_view(),name="natizhe"),
]
