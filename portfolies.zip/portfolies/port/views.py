from django.shortcuts import render
from django.views.generic import ListView
from .models import *
# Create your views here.

def index(req):
    return render(req,"index.html")
class AlgysT(ListView):
    template_name = "algys.html"
    model=Algys
    context_object_name = "algys"
class JymysT(ListView):
    template_name="jymys.html"
    model = Jymys
    context_object_name = "jymys"


class NatizheT(ListView):
    template_name="natizhe.html"
    model = Natizhe
    context_object_name = "natizhe"
def statistika(req):
    return render(req,"statistika.html")
    